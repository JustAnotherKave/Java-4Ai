public class Giocatore {

    private String nome, cognome, ruolo, nazionalità;
    private int numeroMaglia;

    public Giocatore(String nome, String cognome, String ruolo, int numeroMaglia, String nazionalità) {
        this.nome = nome;
        this.cognome = cognome;
        this.ruolo = ruolo;
        this.numeroMaglia = numeroMaglia;
        this.nazionalità=nazionalità;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getRuolo() {
        return ruolo;
    }

    public int getNumeroMaglia() {
        return numeroMaglia;
    }

    public String getNazionalità() {
        return nazionalità;
    }

    public void setNumeroMaglia(int numeroMaglia) {
        this.numeroMaglia = numeroMaglia;
    }
}
