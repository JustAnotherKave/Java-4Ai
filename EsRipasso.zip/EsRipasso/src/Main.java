public class Main{
    static void main(String[] args){
        Giocatore p1 = new Giocatore("Lorenzo","Cavedoni", "attaccante",10,"italia");
        Giocatore p2 = new Giocatore("Jacopo", "Gaetani", "Portiere", 1,"filippine");
        Giocatore p3= new Giocatore("Abd", "Nekkaa","difensore",67,"Africa");
        Squadra s1= new Squadra("SEES", "Ferrara","FukiFuki", "italia",0);
        SquadraInternazionale s2= new SquadraInternazionale("Le Rosse primaverili", "Bologna", "Khaled", "Russia",0 );

        p1.setNumeroMaglia(18);

        s1.AggiungiGiocatore(p1);
        s1.AggiungiGiocatore(p2);
        s1.AggiungiGiocatore(p3);

        s1.nomi();
        s1.nomiAttack();
        s1.giocatoriPresenti();

        s2.Stranieri(p1);
        s2.Stranieri(p2);
        s2.Stranieri(p3);

        s2.countNazionalità();
        s2.stampa();


    }
}
