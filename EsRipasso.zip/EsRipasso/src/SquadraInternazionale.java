public class SquadraInternazionale extends Squadra {
    private Giocatore[] stranieri= new Giocatore[nGiocatori];

    public SquadraInternazionale(String nomeSquadra, String città, String nomeAllenatore, String paese,int giocatoriInSquadra) {
        super(nomeSquadra, città, nomeAllenatore, paese, giocatoriInSquadra);
    }

    public void Stranieri(Giocatore p){

        for(int i=0;i<nGiocatori;i++){

            if(p.getNazionalità()!="Italia"){
                stranieri[i]=p;
            }
        }

    }
    public void countNazionalità(){
        int c=0;
        for(int i=0;i<stranieri.length;i++){
            if(stranieri!=null){
                c++;
            }
        }
        System.out.println("ci sono"+c+" nazionalità diverse");
    }

    public void stampa(){
        System.out.println(getCittà()+" "+getNomeSquadra()+" "+getPaese());

    }
}
