public class Squadra {
    final int nGiocatori=11;
    private String nomeSquadra, città, nomeAllenatore, paese;
    private Giocatore[] elenco= new Giocatore[nGiocatori];
    private int giocatoriInSquadra=0;

    public Squadra(String nomeSquadra, String città, String nomeAllenatore, String paese,int giocatoriInSquadra) {
        this.nomeSquadra = nomeSquadra;
        this.città = città;
        this.nomeAllenatore = nomeAllenatore;
        this.paese=paese;
        this.giocatoriInSquadra=giocatoriInSquadra;

    }

    public String getPaese() {
        return paese;
    }

    public int getnGiocatori() {
        return nGiocatori;
    }

    public String getNomeSquadra() {
        return nomeSquadra;
    }

    public String getCittà() {
        return città;
    }

    public String getNomeAllenatore() {
        return nomeAllenatore;
    }

    public void AggiungiGiocatore(Giocatore p){
       if(giocatoriInSquadra<nGiocatori){
           elenco[giocatoriInSquadra]=p;
           giocatoriInSquadra++;
       }




    }
    public void nomi(){
        for(int i=0;i<nGiocatori;i++){
            System.out.println("-----------NOMI GIOCATORI-----------");
            System.out.println(elenco[i].getNome());

        }
    }
    public void nomiAttack(){
        System.out.println("-------------ATTACCANTI------------");
        for(int i=0; i<nGiocatori;i++){
             if (elenco[i]==null) {
                System.out.println("giocatore assente");

            }
           else if(elenco[i].getRuolo()=="attaccante" ||elenco[i].getRuolo()=="Attaccante" ){
                System.out.println(elenco[i].getNome());
            }
        }
    }
    public void giocatoriPresenti(){
        int c=0;
        for(int i=0;i< elenco.length;i++){
            if(elenco[i]!=null){
                c++;
            }
        }
    }
}
